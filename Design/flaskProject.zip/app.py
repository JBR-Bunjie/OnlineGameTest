from flask import Flask, request
import database_operation

app = Flask(__name__)


@app.route('/data_version')
def data_version():  # Fix Version
    return '0.1.0.1'

@app.route('/data_version')
def app_version():  # Client Version
    return '0.1.0.0'


@app.route('/user_login')
def user_login():
    db = database_operation.DatabaseOperation("identifier.sqlite")
    acc = request.args.get('acc')
    pwd = request.args.get('pwd')
    return db.login(acc, pwd)

@app.route('/user_register')
def user_register():
    db = database_operation.DatabaseOperation("identifier.sqlite")
    acc = request.args.get('acc')
    pwd = request.args.get('pwd')
    try:
        db.register(acc, pwd)
        result = "0! finish"
    except Exception as e:
        result = e.__traceback__

    return result

if __name__ == '__main__':
    app.run(
        # debug=True,
        # port=5000,
        # host='0.0.0.0'
    )
