import sqlite3


class DatabaseOperation:
    def __init__(self, db_name):
        self.db_name = db_name
        self.db = sqlite3.connect(db_name)

    def login(self, account, password):
        cur_obj = self.db.cursor()

        query = f"SELECT account, password FROM USER;"

        cur_obj.execute(query)

        query_results = cur_obj.fetchall()

        if ((account, password) in query_results):
            return "True"
        else:
            return "False"

    def register(self, account, password):
        cur_obj = self.db.cursor()

        query = f"INSERT INTO USER (account, password) VALUES ('{account}', '{password}');"

        cur_obj.execute(query)

        cur_obj.close()
        self.db.commit()

    def select(self, column_name, table_name, *character_name):
        cur_obj = self.db.cursor()

        # main table only:
        if 0 == len(character_name):
            # column_name == name
            query = f"SELECT {column_name} FROM {table_name};"
        else:
            # column_name == lastUpdated; character_name == name
            query = f"SELECT id, {column_name} FROM {table_name} WHERE name == '{character_name[0]}';"

        cur_obj.execute(query)

        query_results = cur_obj.fetchall()

        return query_results

    def insert_main_table(self, character_name, last_updated, table_name, *id_key):
        cur_obj = self.db.cursor()

        if 0 == len(id_key):
            query = f"INSERT INTO {table_name} (name, lastUpdated) VALUES('{character_name}', '{last_updated}');"
        else:
            query = f"INSERT INTO {table_name} (id, name, lastUpdated) VALUES ({id_key[0]}, '{character_name}', '{last_updated}');"

        cur_obj.execute(query)

        self.db.commit()

    def insert_vice_table(self, collection_name, table_name, *id_key):
        cur_obj = self.db.cursor()
        if 0 == len(id_key):
            query = f"INSERT INTO {table_name} (name) VALUES ('{collection_name}');"
        else:
            query = f"INSERT INTO {table_name} (id, name) VALUES ({id_key[0]}, '{collection_name}');"

        cur_obj.execute(query)

        self.db.commit()

    def update(self, table_name, update_item, update_data, id):
        cur_obj = self.db.cursor()

        query = f"UPDATE {table_name} SET {update_item} = '{update_data}' WHERE id == {id};"

        cur_obj.execute(query)

        self.db.commit()

    def delete(self):
        pass

    # in theory, we should keep substitute out, or we need more "necessary process"
    # but here, we just use this in our crawler program, don't worry about sql injection

    def create_main_table(self, main_table_name):
        cur_obj = self.db.cursor()

        query = f"CREATE TABLE IF NOT EXISTS {main_table_name} (id integer PRIMARY KEY AUTOINCREMENT, name text, lastUpdated text);"

        cur_obj.execute(query)

        self.db.commit()

    def create_vice_table(self, character_name):
        cur_obj = self.db.cursor()

        query = f"CREATE TABLE IF NOT EXISTS {character_name} (id integer PRIMARY KEY AUTOINCREMENT, name text);"

        cur_obj.execute(query)

        self.db.commit()
